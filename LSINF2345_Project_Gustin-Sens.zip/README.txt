How to run the code

To run our code, simply run 
	- the function launcher:run_read_file/1 with the path to an input file (this will spawn a client that issues the commands contained in this file)
	- OR the function launcher:run_assessment/0 (this will spawn a client that will simply record the throughput of the program)
	
You can change the parameters of the function called in those two functions to change the number of transaction managers, data partitions or number of messages sent for example, in order to have different behaviors. 
